package com.example.catatan_ringkas_by_ammar

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
